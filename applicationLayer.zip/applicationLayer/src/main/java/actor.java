

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Calendar;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.sql.* ;

import java.io.PrintWriter;
/**
 * Servlet implementation class Retrieve
 */
@WebServlet("/actor")
public class actor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public actor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		 response.setContentType("text/html; charset = utf-8");
		 PrintWriter out = response.getWriter();
		 String docType = "<!doctype html>\n";
	      String moviename = request.getParameter("movieactor");
//	      String password = request.getParameter("password");
	     // JDBC driver name and database URLString JDBC_DRIVER = "com.mysql.jdbc.Driver";
	      //String DB_URL = "jdbc:mysql://52.26.86.130:3306/student";
	      String DB_URL = "jdbc:mysql://3.143.220.151:3306/testDB";
	      // Database credentials
	      String USER = "zsui1";
	      String PASS = "1";
	      Connection conn = null;

	      //STEP 2: Register JDBC driver
	      out.println();
	      try { 
	    	  String sql;
		      sql = "SELECT * FROM movies WHERE name=(?)";
	      Class.forName("com.mysql.jdbc.Driver");
	      //STEP 3: Open a connection
	      System.out.println("Connecting to database...");
	      conn = (Connection) DriverManager.getConnection(DB_URL,USER,PASS);
	      //STEP 4: Execute a query
	      System.out.println("Creating statement...");
	      PreparedStatement stmt = conn.prepareStatement(sql);
	      stmt.setString(1,moviename);
	      ResultSet rs = (ResultSet) stmt.executeQuery();
	      boolean temp = false;
	      //STEP 5: Extract data from result set
	      while(rs.next()) {
	    	  String movienameindb = rs.getString("name");
		      String comments = rs.getString("cast");
		      String picture = rs.getString("picture");
		      String[] parts = comments.split("-");
		      String[] abc = {"a","b","c"};
/*
		      if(parts[1]==null) {
		    	  parts[1] = "actor2";
		      }
		      if(parts[2]==null) {
		    	  parts[2] = "actor3";
		      }*/
		      String temp1=new String();
		      for(int i=0;i<parts.length;i++) {
		    	  temp1 = temp1 +"&actor"+abc[i]+"="+parts[i].replaceAll("\\s","+");
		      }
		      if(!comments.isEmpty() && movienameindb.equals(moviename) ){
		    	  out.println(docType +
			    			"<html>\n"+
			    			"<body>\n"+
			    			"<p>"+"you search actors for"+movienameindb+"</p>"+
			    			"<a href="+"moviesingle_1.html"+"?"+
			    			"name="+movienameindb.replaceAll("\\s","+")+
			    			temp1+
			    			"&"+
			    			"picture="+picture+
			    			"&"+
			    			"mode=actor"+
			    			">"+
			    			"go forward"+
			    			"<a>"+
			    			"\n"+
			    			"</body></html>");
		    	  temp =true;
		      }
	      }
	      if (temp == false) {
	    	  out.println(docType +
		    			"<html>\n"+
		    			"<body>\n"+
		    			"<p>"+"Your input: information is not complete,try again"+"</p>"+"<a href="+"MainPage1.html"+">"+"go back"+"<a>"+"\n"+
		    			"</body></html>");
	      }
	      rs.close();
	      stmt.close();
	      conn.close();
	      } catch (ClassNotFoundException | SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	      }
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

