

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Calendar;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.sql.* ;

import java.io.PrintWriter;
/**
 * Servlet implementation class Retrieve
 */
@WebServlet("/movies")
public class movies extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public movies() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		 response.setContentType("text/html; charset = utf-8");
		 PrintWriter out = response.getWriter();
		 String docType = "<!doctype html>\n";
	      String moviename = request.getParameter("movieproductor");
//	      String password = request.getParameter("password");
	     // JDBC driver name and database URLString JDBC_DRIVER = "com.mysql.jdbc.Driver";
	      //String DB_URL = "jdbc:mysql://52.26.86.130:3306/student";
	      String DB_URL = "jdbc:mysql://3.143.220.151:3306/testDB";
	      // Database credentials
	      String USER = "zsui1";
	      String PASS = "1";
	      Connection conn = null;
	      Calendar calendar =Calendar.getInstance();
          int weekday =calendar.get(Calendar.DAY_OF_WEEK);
	      //STEP 2: Register JDBC driver
	      out.println();
	      try { 
	    	  String sql;
		      sql = "SELECT name,picture FROM movies ORDER by rate desc limit 10";
	      Class.forName("com.mysql.jdbc.Driver");
	      //STEP 3: Open a connection
	      System.out.println("Connecting to database...");
	      conn = (Connection) DriverManager.getConnection(DB_URL,USER,PASS);
	      //STEP 4: Execute a query
	      System.out.println("Creating statement...");
	      PreparedStatement stmt = conn.prepareStatement(sql);
//	      stmt.setString(1,String.valueOf(weekday));
	      ResultSet rs = (ResultSet) stmt.executeQuery();
	      boolean temp = false;
	      String temp1=new String();
	      String temp2=new String();
	      String temp3=new String();
	      String movienameindb=new String();
	      String picture=new String();
	      int count =1;
	      //STEP 5: Extract data from result set
	      while(rs.next()) {
	    	  String movienameindb1 = rs.getString("name");
		      /*String comments = rs.getString("producer");*/
		      String picture1 = rs.getString("picture");
		      //Integer rating = rs.getInt("rate");
		      temp1= temp1+"&"+"movie"+String.valueOf(count)+"="+ movienameindb1.replaceAll("\\s","+"); 
		      temp2= temp2+"&"+"picture"+String.valueOf(count)+"="+ picture1; 
		      //temp3= temp3+"&"+"rate"+String.valueOf(count)+"="+ String.valueOf(rating);
		      count++;
		      }
	          out.println(docType +
	    			"<html>\n"+
	    			"<body>\n"+
	    			"<p>"+"you search today movies in theater for"+movienameindb+"</p>"+
	    			"<a href="+"moviesingle.html"+"?"+
	    			temp2+
	    			temp1+
	    			//temp3+
	    			"&"+
	    			"mode=top10"+
	    			"&"+
	    			"count="+String.valueOf(count)+
	    			">"+
	    			"go forward"+
	    			"<a>"+
	    			"\n"+
	    			"</body></html>");
	      
    	  

	      rs.close();
	      stmt.close();
	      conn.close();
	      } catch (ClassNotFoundException | SQLException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	      }
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}



